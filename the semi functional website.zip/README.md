
# Riget Zoo Adventures — T Level OS Website Starter

This is a minimal, assessment-aligned starter you can extend for your Occupational Specialism.

## Features implemented
- Home page with featured animals loaded from `/api/animals`
- Tickets page with validated booking form (date cannot be in the past; qty 1–10)
- Booking confirmation page and stored bookings in `data/bookings.json`
- Simple loyalty points (10 per ticket) stored in `data/users.json`
- Accessibility: skip link, high-contrast toggle (cookie), adjustable font size, alt text
- Cookie banner (consent stored in localStorage)
- API endpoints for animals and user lookup
- Clear folder structure and maintainable code

## Tech (meets "two languages" requirement)
- Front end: HTML, CSS, JavaScript
- Back end: Python (Flask) + JSON storage (you can later swap to SQLite)

## How to run
1. Ensure Python 3.10+ is installed.
2. Install dependencies: `pip install flask`
3. Run: `python app.py`
4. Open: http://127.0.0.1:5000

## Next steps for Distinction
- Add hotel booking alongside tickets
- Implement account registration/login (hash passwords)
- Replace JSON with SQLite (SQL language) and show an ERD
- Add input sanitisation on the server and client
- Add more WCAG features (focus styles, ARIA where helpful)
- Create a comprehensive test plan and capture screenshots
- Add versioning: create tags/releases for V1, V2, etc.

## Legal & Standards
- Add a Privacy Policy and Terms page
- Ensure GDPR considerations if you store personal data
- Include a cookie preferences modal if doing analytics
