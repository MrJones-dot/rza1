# Changelog

All notable changes to this project will be documented in this file.
This project follows Semantic Versioning (MAJOR.MINOR.PATCH).

FORMAT

- Each release: a heading with version and date (YYYY-MM-DD).
## [2.0.0] - 2025-11-21
### Added
 - payment system
 - authentication stickers
 - additional admin functionality
 - additional UI improvements
 - about section


## [1.5.0] - 2025-11-21
### Added
 - Multiple Admin Features:
    - Deleting bookings
    - Appointing other admin
    - add new animals

## [1.4.0] - 2025-11-20
### Added
 - Admin portal

## [1.3.0] - 2025-11-20
### Added
 - Admin accounts and route

## [1.2.1] - 2025-11-15
### Fixed
 - Syntax error in admin feild

## [1.2.0] - 2025-11-15
### Added
 - Admin feild for future funcionality

## [1.1.0] - 2025-11-10
### Added
- Accounts with points system, changed UI layout for better optimization


## [1.0.1] - 2025-11-05
### Added
- images for animals


## [1.0.0] - 2025-11-05
### Added
- Initial release: core functionality | bookings, connectivity, layout, data validation
