from flask import Flask, render_template, request, jsonify, redirect, url_for, make_response, session
from flask_bcrypt import Bcrypt
import json
import os
from datetime import datetime

app = Flask(__name__, static_folder="static", template_folder="templates")
bcrypt = Bcrypt(app)
app.secret_key = "supersecretkey"  # For coursework only; use env var in real apps

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
TICKET_PRICE = 15.00  # £15 per ticket (simulation only)


# --------- Helpers for JSON storage ---------

def load_json(name):
    path = os.path.join(DATA_DIR, name)
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_json(name, data):
    path = os.path.join(DATA_DIR, name)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def get_current_user():
    """Return the currently logged-in user dict, or None."""
    email = session.get("user_email")
    if not email:
        return None
    users = load_json("users.json")
    return next((u for u in users if u.get("email", "").lower() == email.lower()), None)


# --------- Public pages ---------

@app.route("/")
def home():
    animals = load_json("animals.json")
    return render_template("index.html", animals=animals)


@app.route("/tickets")
def tickets():
    return render_template("tickets.html")


# --------- Booking and payment ---------

@app.route("/book", methods=["POST"])
def book():
    bookings = load_json("bookings.json")
    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip()
    date = request.form.get("date", "").strip()
    qty_raw = request.form.get("qty", "0")
    errors = []

    # Basic validation
    if not name:
        errors.append("Name is required.")
    if "@" not in email or "." not in email:
        errors.append("Valid email is required.")

    try:
        qty = int(qty_raw)
    except ValueError:
        qty = 0
    if qty < 1 or qty > 10:
        errors.append("Tickets must be between 1 and 10.")

    try:
        chosen = datetime.strptime(date, "%Y-%m-%d").date()
        if chosen < datetime.today().date():
            errors.append("Date cannot be in the past.")
    except Exception:
        errors.append("Valid date is required.")

    if errors:
        # Re-render tickets page with errors and previous form values
        return render_template("tickets.html", errors=errors, form=request.form), 400

    # Create booking
    booking = {
        "id": len(bookings) + 1,
        "name": name,
        "email": email,
        "date": date,
        "qty": qty,
        "created_at": datetime.utcnow().isoformat() + "Z",
        "total_price": round(qty * TICKET_PRICE, 2),
        "paid": False
    }
    bookings.append(booking)
    save_json("bookings.json", bookings)

    # Simple loyalty: 10 points per ticket
    users = load_json("users.json")
    user = next((u for u in users if u["email"].lower() == email.lower()), None)
    if user is None:
        user = {
            "email": email,
            "name": name,
            "points": 0,
            "is_admin": False
        }
        users.append(user)
    user["points"] += qty * 10
    save_json("users.json", users)

    return redirect(url_for("booking_success", booking_id=booking["id"]))


@app.route("/booking/<int:booking_id>")
def booking_success(booking_id):
    bookings = load_json("bookings.json")
    booking = next((b for b in bookings if b["id"] == booking_id), None)
    return render_template("booking_success.html", booking=booking)


@app.route("/pay/<int:booking_id>", methods=["GET", "POST"])
def pay(booking_id):
    """Simulated card payment page for a booking."""
    bookings = load_json("bookings.json")
    booking = next((b for b in bookings if b["id"] == booking_id), None)
    if not booking:
        return "Booking not found", 404

    # If already paid, just send them back
    if booking.get("paid"):
        return redirect(url_for("booking_success", booking_id=booking_id))

    errors = []
    form = {}

    if request.method == "POST":
        form["card_name"] = request.form.get("card_name", "").strip()
        form["card_number"] = request.form.get("card_number", "").replace(" ", "")
        form["expiry_month"] = request.form.get("expiry_month", "").strip()
        form["expiry_year"] = request.form.get("expiry_year", "").strip()
        form["cvv"] = request.form.get("cvv", "").strip()

        # Simulated validation (not real processing)
        if not form["card_name"]:
            errors.append("Name on card is required.")

        if not (form["card_number"].isdigit() and len(form["card_number"]) == 16):
            errors.append("Card number must be 16 digits (simulation only).")

        if not (form["cvv"].isdigit() and len(form["cvv"]) == 3):
            errors.append("CVV must be 3 digits.")

        # Expiry date
        try:
            month = int(form["expiry_month"])
            year = int(form["expiry_year"])
            if month < 1 or month > 12:
                errors.append("Expiry month must be between 1 and 12.")
            else:
                now = datetime.today()
                if year < now.year or (year == now.year and month < now.month):
                    errors.append("Card is expired.")
        except ValueError:
            errors.append("Expiry month and year must be numbers.")

        if not errors:
            # Mark booking as paid
            booking["paid"] = True
            booking["paid_at"] = datetime.utcnow().isoformat() + "Z"
            save_json("bookings.json", bookings)
            return redirect(url_for("booking_success", booking_id=booking_id))

    return render_template("pay.html", booking=booking, errors=errors, form=form)


# --------- JSON API endpoints ---------

@app.route("/api/animals")
def api_animals():
    return jsonify(load_json("animals.json"))


@app.route("/api/users/<email>")
def api_user(email):
    users = load_json("users.json")
    user = next((u for u in users if u["email"].lower() == email.lower()), None)
    if not user:
        return jsonify({"error": "not found"}), 404
    return jsonify(user)


# --------- Admin dashboard & tools ---------

@app.route("/admin")
def admin_dashboard():
    user = get_current_user()
    if not user or not user.get("is_admin"):
        return redirect(url_for("login"))

    bookings = load_json("bookings.json")
    users = load_json("users.json")
    animals = load_json("animals.json")

    return render_template(
        "admin.html",
        user=user,
        bookings=bookings,
        users=users,
        animals=animals,
    )


@app.route("/admin/bookings/delete", methods=["POST"])
def admin_delete_booking():
    user = get_current_user()
    if not user or not user.get("is_admin"):
        return redirect(url_for("login"))

    index = int(request.form["index"])  # index of booking in the list
    bookings = load_json("bookings.json")
    if 0 <= index < len(bookings):
        bookings.pop(index)
        save_json("bookings.json", bookings)

    return redirect(url_for("admin_dashboard"))


@app.route("/admin/animals/add", methods=["POST"])
def admin_add_animal():
    user = get_current_user()
    if not user or not user.get("is_admin"):
        return redirect(url_for("login"))

    name = request.form["name"]
    species = request.form["species"]
    description = request.form.get("description", "")

    animals = load_json("animals.json")
    animals.append(
        {
            "name": name,
            "species": species,
            "description": description,
        }
    )
    save_json("animals.json", animals)

    return redirect(url_for("admin_dashboard"))


@app.route("/admin/users/make-admin", methods=["POST"])
def admin_make_user_admin():
    user = get_current_user()
    if not user or not user.get("is_admin"):
        return redirect(url_for("login"))

    email = request.form["email"].lower()

    users = load_json("users.json")
    for u in users:
        if u.get("email", "").lower() == email:
            u["is_admin"] = True
            break

    save_json("users.json", users)
    return redirect(url_for("admin_dashboard"))


# --------- Accessibility toggle ---------

@app.route("/accessibility/toggle-contrast")
def toggle_contrast():
    resp = make_response(redirect(request.referrer or url_for("home")))
    current = request.cookies.get("contrast", "off")
    new = "on" if current != "on" else "off"
    resp.set_cookie("contrast", new, max_age=60 * 60 * 24 * 365, samesite="Lax")
    return resp


# --------- Auth: register / login / logout ---------

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").lower().strip()
        password = request.form.get("password", "").strip()
        users = load_json("users.json")

        if not name or not email or not password:
            return render_template("register.html", error="All fields required.")
        if any(u["email"] == email for u in users):
            return render_template("register.html", error="Email already registered.")

        hashed = bcrypt.generate_password_hash(password).decode("utf-8")
        users.append(
            {
                "name": name,
                "email": email,
                "password": hashed,
                "points": 0,
                "is_admin": False,
            }
        )
        save_json("users.json", users)
        session["user_email"] = email
        return redirect(url_for("home"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").lower().strip()
        password = request.form.get("password", "").strip()
        users = load_json("users.json")
        user = next((u for u in users if u["email"] == email), None)

        if user and bcrypt.check_password_hash(user["password"], password):
            session["user_email"] = email
            return redirect(url_for("home"))
        else:
            return render_template("login.html", error="Invalid email or password.")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.pop("user_email", None)
    return redirect(url_for("home"))


if __name__ == "__main__":
    app.run(debug=True)
