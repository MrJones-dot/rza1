
(function(){
  // Font size controls
  const html = document.documentElement;
  const getSize = () => parseFloat(getComputedStyle(html).getPropertyValue("font-size"));
  document.getElementById("fontInc").addEventListener("click", () => html.style.fontSize = (getSize()+1) + "px");
  document.getElementById("fontDec").addEventListener("click", () => html.style.fontSize = Math.max(12, getSize()-1) + "px");

  // Cookie banner
  const banner = document.getElementById("cookieBanner");
  const accepted = localStorage.getItem("cookiesAccepted");
  if(!accepted){ banner.hidden = false; }
  document.getElementById("acceptCookies").addEventListener("click", () => { localStorage.setItem("cookiesAccepted","yes"); banner.hidden=true; });
  document.getElementById("rejectCookies").addEventListener("click", () => { localStorage.setItem("cookiesAccepted","no"); banner.hidden=true; });

  // Load animals
  const animalsEl = document.getElementById("animals");
  if(animalsEl){
    fetch("/api/animals").then(r=>r.json()).then(list=>{
      const tpl = document.getElementById("cardTpl");
      list.slice(0,8).forEach(a=>{
        const node = tpl.content.cloneNode(true);
        node.querySelector(".card-img").src = a.image;
        node.querySelector(".card-img").alt = a.name;
        node.querySelector(".card-title").textContent = a.name;
        node.querySelector(".card-text").textContent = a.description;
        animalsEl.appendChild(node);
      });
    });
  }

  // Loyalty check
  const form = document.getElementById("loyaltyForm");
  if(form){
    form.addEventListener("submit", async (e)=>{
      e.preventDefault();
      const email = document.getElementById("lEmail").value.trim();
      const out = document.getElementById("loyaltyResult");
      out.textContent = "Checking…";
      const res = await fetch("/api/users/" + encodeURIComponent(email));
      if(res.ok){
        const data = await res.json();
        out.textContent = `Hello ${data.name ?? ''} — you have ${data.points} points.`;
      } else {
        out.textContent = "No account found for that email yet.";
      }
    });
  }
})();
