
from flask import Flask, render_template, request, jsonify, redirect, url_for, make_response, session, session
from flask_bcrypt import Bcrypt
import json, os
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

app = Flask(__name__, static_folder="static", template_folder="templates")
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")

def load_json(name):
    path = os.path.join(DATA_DIR, name)
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def save_json(name, data):
    path = os.path.join(DATA_DIR, name)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

@app.route("/")
def home():
    animals = load_json("animals.json")
    return render_template("index.html", animals=animals)

@app.route("/tickets")
def tickets():
    return render_template("tickets.html")

@app.route("/book", methods=["POST"])
def book():
    bookings = load_json("bookings.json")
    name = request.form.get("name","").strip()
    email = request.form.get("email","").strip()
    date = request.form.get("date","").strip()
    qty = int(request.form.get("qty","0"))
    errors = []
    if not name: errors.append("Name is required.")
    if "@" not in email: errors.append("Valid email is required.")
    try:
        chosen = datetime.strptime(date, "%Y-%m-%d").date()
        if chosen < datetime.today().date():
            errors.append("Date cannot be in the past.")
    except Exception:
        errors.append("Valid date is required.")
    if qty < 1 or qty > 10: errors.append("Tickets must be between 1 and 10.")
    if errors:
        return render_template("tickets.html", errors=errors, form=request.form), 400
    booking = {
        "id": len(bookings)+1,
        "name": name,
        "email": email,
        "date": date,
        "qty": qty,
        "created_at": datetime.utcnow().isoformat()+"Z"
    }
    bookings.append(booking)
    save_json("bookings.json", bookings)
    # Simple loyalty: 10 points per ticket
    users = load_json("users.json")
    user = next((u for u in users if u["email"].lower()==email.lower()), None)
    if user is None:
        user = {"email": email, "name": name, "points": 0}
        users.append(user)
    user["points"] += qty*10
    save_json("users.json", users)
    return redirect(url_for("booking_success", booking_id=booking["id"]))

@app.route("/booking/<int:booking_id>")
def booking_success(booking_id):
    bookings = load_json("bookings.json")
    booking = next((b for b in bookings if b["id"]==booking_id), None)
    return render_template("booking_success.html", booking=booking)

@app.route("/api/animals")
def api_animals():
    return jsonify(load_json("animals.json"))

@app.route("/api/users/<email>")
def api_user(email):
    users = load_json("users.json")
    user = next((u for u in users if u["email"].lower()==email.lower()), None)
    if not user: 
        return jsonify({"error":"not found"}), 404
    return jsonify(user)

@app.route("/accessibility/toggle-contrast")
def toggle_contrast():
    resp = make_response(redirect(request.referrer or url_for("home")))
    current = request.cookies.get("contrast","off")
    new = "on" if current!="on" else "off"
    resp.set_cookie("contrast", new, max_age=60*60*24*365, samesite="Lax")
    return resp

bcrypt = Bcrypt(app)
app.secret_key = "supersecretkey"  # Replace with something secure!

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").lower().strip()
        password = request.form.get("password", "").strip()
        users = load_json("users.json")

        if not name or not email or not password:
            return render_template("register.html", error="All fields required.")
        if any(u["email"] == email for u in users):
            return render_template("register.html", error="Email already registered.")

        hashed = bcrypt.generate_password_hash(password).decode("utf-8")
        users.append({"name": name, "email": email, "password": hashed, "points": 0})
        save_json("users.json", users)
        session["user_email"] = email
        return redirect(url_for("home"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").lower().strip()
        password = request.form.get("password", "").strip()
        users = load_json("users.json")
        user = next((u for u in users if u["email"] == email), None)

        if user and bcrypt.check_password_hash(user["password"], password):
            session["user_email"] = email
            return redirect(url_for("home"))
        else:
            return render_template("login.html", error="Invalid email or password.")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.pop("user_email", None)
    return redirect(url_for("home"))

if __name__ == "__main__":
    app.run(debug=True)
