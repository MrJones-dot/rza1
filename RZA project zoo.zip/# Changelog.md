# Changelog

All notable changes to this project will be documented in this file.
This project follows Semantic Versioning (MAJOR.MINOR.PATCH).

FORMAT
- Group changes by type: Added, Changed, Deprecated, Removed, Fixed, Security.
- Each release: a heading with version and date (YYYY-MM-DD).
- Keep an "Unreleased" section for in-progress changes.

## [Unreleased]
### Added
- Short, specific bullet describing new features.

### Changed
- Short summary of notable behavioral changes.

### Fixed
- Bug fixes.

### Security
password hashing - 1.1.0

## [1.1.0] - 2025-11-10
### Added
- Accounts with points system, changed UI layout for better optimization


## [1.0.1] - 2025-11-05
### Added
- images for animals


## [1.0.0] - 2025-11-05
### Added
- Initial release: core functionality | bookings, connectivity, layout, data validation
